# RayBot Pinger

Pings `<@&1500234218783899820>` every time RayBot posts in your wallet tracker channel.

---

## Deploy to Railway (step by step)

### 1. Create a GitHub repo
- Go to https://github.com/new
- Name it `raybot-pinger`
- Set it to Private
- Click **Create repository**

### 2. Upload the files
Upload these 2 files to the repo:
- `bot.js`
- `package.json`

### 3. Create a Discord bot
- Go to https://discord.com/developers/applications
- Click **New Application** → give it a name → **Create**
- Go to **Bot** tab → click **Add Bot**
- Under **Privileged Gateway Intents**, turn ON:
  - `MESSAGE CONTENT INTENT`
  - `SERVER MEMBERS INTENT`
- Click **Reset Token** → copy the token (save it, you only see it once)

### 4. Invite the bot to your server
- Go to **OAuth2** → **URL Generator**
- Scopes: check `bot`
- Bot Permissions: check `Send Messages`, `View Channels`, `Mention Everyone`
- Copy the generated URL and open it in your browser
- Select your server and authorize

### 5. Deploy on Railway
- Go to https://railway.com
- Click **New Project** → **Deploy from GitHub repo**
- Select `raybot-pinger`
- Go to **Variables** tab and add:
  - Key: `DISCORD_TOKEN`
  - Value: (paste your bot token from step 3)
- Railway will auto-deploy. Done.

---

## What it does
Every time RayBot posts **any message** (including embeds) in the watch channel, the bot immediately sends `<@&1500234218783899820>` in the same channel.
